# Run your n8n regression check locally

1. Install and start Docker (Docker Desktop on macOS; Docker Engine/Desktop on Linux).
2. Extract all four files into a dedicated directory.
3. Open a terminal in that directory and run:

```sh
sh run.sh
```

Selected n8n release: **2.41.7**. To test another exact release:

```sh
N8N_VERSION=2.41.7 sh run.sh
```

The first run downloads the official n8n image and n8n-check v0.1.8. Docker supplies Node. The new runner download is checked once against the pinned release checksum, then stored in .cache. Subsequent runs reuse Docker layers and the cached archive. An uncached n8n version needs internet access. Choose a published version supported by your workflow's nodes and the runner (Node 24+).

The workflow executes with Docker --network none: HTTP mocks use loopback, and external networking is disabled. workflow.json and case.json are mounted read-only; results/ is writable. Execution uses your local UID/GID and a fresh n8n database. Use trusted workflows and synthetic fixtures; workflow code executes in the container. Inline values and assertion differences can appear in local reports.

Results: results/report.json and results/junit.xml. Exit codes: 0 passed, 1 regression, 2 setup error. Each attempt clears the previous two report files; setup errors appear in the terminal. Save reports before rerunning when comparing versions.

Keep Docker running and allow it access to this directory. Windows users can run the bundle inside WSL with Docker integration. Directory paths may contain spaces; choose paths free of commas, colons and line breaks for Docker bind mounts.

Edit case.json to add fixtures, HTTP contracts or assertions, then rerun the same command. The bundle contains the original workflow export and the case selected in the builder; review their contents before sharing.

Runner: https://github.com/blucca/n8n-check/releases/download/v0.1.8/blucca-n8n-check-0.1.8.tgz
SHA256: 5b293268f172e7ba1c51172e707dcd5546b1ca52c952444899a380ff75b84864
Documentation: https://github.com/blucca/n8n-check
